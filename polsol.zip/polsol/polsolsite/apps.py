from django.apps import AppConfig


class PolsolsiteConfig(AppConfig):
    name = 'polsolsite'
